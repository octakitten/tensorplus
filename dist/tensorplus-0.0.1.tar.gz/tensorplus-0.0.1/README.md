TensorPlus

What is this?

This is a in-development Tensor library written in Cuda and C and ready to be imported into a Python package with CPython (that package will be forthcoming soon). It aims at streamlining machine learning-relevant tensor operations that more popular, well-treaded libraries like Tensorflow and Pytorch have neglected. Specifically, it is built with the intention of being used by the OpenCB Python library to speed up its operations.